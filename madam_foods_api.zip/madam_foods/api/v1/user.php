<?php
require_once "condb.php" ;

switch ( $property ) {
   case "me": 
        // Example SELECT query
        $query = "SELECT username,expire  FROM log_user where token = '$main_tokey' and del = 0 ";
        $stmt = $db->query($query);
        $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo return_json($res) ;
    break ;  
    case "logoff": 
        $_SESSION['user'] = '' ;
        echo return_json($res) ;
    break ;  

    default:
        echo return_json404() ;
}
