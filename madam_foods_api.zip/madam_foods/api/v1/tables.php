<?php
require_once "condb.php" ;

switch ( $property ) {
    case "getall": 
        // Example SELECT query
        $query = "SELECT *  FROM tables";
        $stmt = $db->query($query);
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // Display retrieved data
       // $products = 'xxxx'/* Fetch products from database */;
        echo return_json($products) ;

    break ;

    default:
        echo return_json404() ;
}
