<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Database credentials
$host = "localhost"; // Change to your database host
$dbname = "madam_foods"; // Change to your database name
$username = "root"; // Change to your database username
$password = ""; // Change to your database password
if(session_id() == ''){
  session_start();
}
try {
    // Create a new PDO instance
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);

    // Set PDO error mode to exception
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}


?>