<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include('func.php') ;

// Allow from any origin
if (isset($_SERVER['HTTP_ORIGIN'])) {
    // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
    // you want to allow, and if so:
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        // may also be using PUT, PATCH, HEAD etc
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

    exit(0);
}

date_default_timezone_set("Asia/Bangkok");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header('Access-Control-Allow-Methods: GET, POST,PUT,DELETE, OPTIONS');
header('Content-Type: text/html; charset=utf-8');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

//bug for cross platform
header('Access-Control-Allow-Headers: Content-Type,x-prototype-version,x-requested-with');

global $request_method ;
$request_method = $_SERVER["REQUEST_METHOD"];
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode('/', $uri);
$method = $_GET['request'] ;
$query = explode('/', $method);
$property = $query[1] ;
$data = '' ; //id 
$main_tokey = '' ;
switch($request_method ){
	case "GET" : 
		$data = $_GET ;	
	break ;
	case "POST" :
		$data = json_decode(file_get_contents("php://input"), true);
        $data = $data ? $data : $_POST ;
	break ;	
}
switch($query[0]){
    case  "login" :
        require_once $query[0].".php" ;
    break ;
    default :
        if ( !file_exists($query[0].".php")) {

            echo return_json404()  ;
            return ;
        }

        //get header
        $main_tokey = getBearerToken() ; 
        // Example SELECT query
        $sql = "SELECT username,expire  FROM log_user where token = '$main_tokey' and del = 0 ";
        $stmt = $db->query($sql);
        $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ( $res && $main_tokey) {
            require_once $query[0].".php" ;            
        // check for auth         
        }else{
            echo return_json203() ;
        }

}

