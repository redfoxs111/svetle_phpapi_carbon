<?php
require_once "condb.php" ;

switch ( $property ) {
    case "login": 
        $user = $data['username'] ;
        $pws = $data['password'] ;

        // Example SELECT query
        $query = "SELECT user,username  FROM user where user = '$user'  and pws = '$pws' ";
        $stmt = $db->query($query);
        $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $logindate = strtotime( date('Y-m-d H:i:s') ) ;
        $expiredate_int = ($logindate) + 43200 ;
        $expiredate = date('Y-m-d H:i:s', $expiredate_int) ;    
        $ctoken = '' ;
        $_SESSION['user'] = $user ;
        if ( $res ) {
            $ctoken = token( $res[0]['user'].','.$res[0]['username'] .','.$logindate .','.$expiredate_int ) ;
            $res['token'] = $ctoken ;
            $res['expire'] = $expiredate_int ;
            // insert token
            $query = "update log_user set del = 1 where expire < $logindate" ;
            $stmt = $db->query($query);


            // insert token
            $query = "insert into log_user (token,username,sdate,expire,del) value ('$ctoken' , '$user',$logindate,$expiredate_int,0 )" ;
            $stmt = $db->query($query);
        }


        echo return_json($res) ;
    break ;    
    case "logoff": 
        $_SESSION['user'] = '' ;
        echo return_json($res) ;
    break ;  

    default:
        echo return_json404() ;
}
